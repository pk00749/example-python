py2app is a Python setuptools command which will allow
you to make standalone Mac OS X application bundles
and plugins from Python scripts.

py2app is similar in purpose and design to py2exe for
Windows.

NOTE: py2app must be used on OSX to build applications,
it cannot create Mac applications on other platforms.
