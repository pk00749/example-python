import code
import foo
print("Helper 2: %s"%(foo.sq_2,))
