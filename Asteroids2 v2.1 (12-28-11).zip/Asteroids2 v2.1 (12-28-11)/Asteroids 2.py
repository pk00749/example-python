from game import main

main.PlayAsteroids()
