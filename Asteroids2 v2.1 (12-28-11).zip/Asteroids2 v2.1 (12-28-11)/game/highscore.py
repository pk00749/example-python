"""This module controls the high scores and allows the game to be played repeatably"""
import pygame, os

WHITE = (255, 255, 255)
YELLOW = (255, 255, 0)
WIDTH, HEIGHT = 800, 500

class Highscore:

    def __init__(self):
        self.highfont = pygame.font.SysFont("Jokerman", 20)
        self.highscore = self.highfont.render("High Scores:", True, WHITE)
        self.backscore = self.highfont.render("BACK", True, WHITE)
        self.tryagain = self.highfont.render("TRY AGAIN", True, WHITE)

        self.highfont2 = pygame.font.SysFont("Jokerman", 25)
        self.newhigh = self.highfont.render("NEW HIGH SCORE", True, YELLOW)
        
        self.highscores = []
        
        f = open("High Scores.txt", "r")
        for i in xrange(10):
            highscore = f.readline()
            highscore = int(highscore[:-1])
            self.highscores.append(highscore)
        f.close()

        self.frame_m3 = 2
        self.update_time_m3 = 0

    def update_high(self):

        self.scorecopy = self.score

        self.highscores_im = []
        self.lowestvalue = self.highscores[9]

        f = open("High Scores.txt", "w")

        for i in xrange(len(self.highscores)):
            if self.score >= self.highscores[i]:
                self.p_score = self.highscores[i]
                self.highscores[i] = self.score
                self.score = self.p_score

        for i in self.highscores:
            f.write(str(i)+"\n")
            i = self.highfont.render(str(i), True, WHITE)
            self.highscores_im.append(i)

        f.close()

    def render(self, screen, background, pieces):
        t = pygame.time.get_ticks()
        if self.MENU_H:
            screen.blit(background, (0, 0))
            screen.blit(self.highscore, (WIDTH/2 - self.highscore.get_width()/2, 15))
            screen.blit(self.backscore, (WIDTH/2 - self.backscore.get_width()/2, 400))
            screen.blit(pieces[self.frame_m3], (370, 393))
            a = 2
            for i in self.highscores_im:
                screen.blit(i, (WIDTH/2 - i.get_width()/2, a*30))
                a += 1
        else:
            screen.blit(background, (0, 0))
            screen.blit(self.highscore, (WIDTH/2 - self.highscore.get_width()/2, 15))
            screen.blit(self.tryagain, (WIDTH/2 - self.tryagain.get_width()/2, 400))
            screen.blit(pieces[self.frame_m3], (343, 393))
            a = 2
            for i in self.highscores_im:
                screen.blit(i, (WIDTH/2 - i.get_width()/2, a*30))
                a += 1
            if self.scorecopy > self.lowestvalue:
                screen.blit(self.newhigh, (WIDTH/2 - self.newhigh.get_width()/2, 450))
                
        if t - self.update_time_m3 > 1000:
            self.frame_m3 += 1
            if self.frame_m3 == 3:
                self.frame_m3 = 0
            self.update_time_m3 = t
                

