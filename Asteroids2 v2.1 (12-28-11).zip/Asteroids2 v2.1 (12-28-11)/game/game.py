"This module is where rendering of the actual game occurs"""
import pygame
from spaceship import *
from highscore import Highscore
from asteroids import A_Explosion

WHITE = (255, 255, 255)
WIDTH, HEIGHT = 800, 500

class Game(Cursor):

    def __init__(self, fps2 = 8):
        Cursor.__init__(self)

        self.PLAYING = True
        self.CONTINUESHOT = True

        self.asteroidgroup = pygame.sprite.RenderUpdates()
        self.spaceshipgroup = pygame.sprite.GroupSingle()
        self.spaceshipgroup.add(Spaceship())
        self.bulletgroup = pygame.sprite.RenderUpdates()

        self.SHOOTING = False
        self.damage = {}
        
        self.scorefont = pygame.font.SysFont("Jokerman", 20)
        self.score = 0
        self.angle = 0

        self.update_time2 = 0
        self.delay2 = 1000/fps2
        
    def render(self, screen, background, time):
        screen.blit(background, (0, 0))
        self.Score = self.scorefont.render("Score: %i" %self.score, True, WHITE)
        screen.blit(self.Score, (WIDTH/2 - self.Score.get_width()/2, 15))
            
        self.asteroidgroup.draw(screen)
        self.bulletgroup.draw(screen)
        self.spaceshipgroup.draw(screen)

        screen.blit(self.cursor, (pygame.mouse.get_pos()[0] - self.cursor.get_width()/2,
                                      pygame.mouse.get_pos()[1] - self.cursor.get_height()/2))
                
        self.asteroidgroup.update(pygame.time.get_ticks())
        self.bulletgroup.update(pygame.time.get_ticks())
        self.spaceshipgroup.update(pygame.time.get_ticks())
        Cursor.update(self, pygame.time.get_ticks())

        if time - self.update_time2 > self.delay2:
            if self.SHOOTING and self.CONTINUESHOT:
                self.laser.play()
                self.bulletgroup.add(Bullet(self.bullet_pieces, self.spaceshipgroup.sprite, 10))
            self.update_time2 = time

        self.cleanup()

        if len(self.spaceshipgroup.sprites()) == 0:
            self.GAME = False
            self.HIGHSCORE = True
            Highscore.update_high(self)

    def cleanup(self):

        for a in self.bulletgroup.sprites():
            if a.rect[0] > WIDTH or a.rect[0] < 0 or a.rect[1] > HEIGHT or a.rect[1] < 0:
                a.kill()

        for a in self.asteroidgroup.sprites():
            if a.rect[0] > WIDTH + 500 or a.rect[0] < -500 or a.rect[1] > HEIGHT + 500 or a.rect[1] < -500:
                a.kill()

        for a in pygame.sprite.groupcollide(self.bulletgroup, self.asteroidgroup, True, False).values():
            if self.damage.__contains__(a[0]):
                self.damage[a[0]] += 1
                if self.damage[a[0]] >= 7:
                    self.laser.stop()
                    self.a_explosion.play()
                    self.asteroidgroup.add(A_Explosion(self.a_explode_pieces, a[0].rect, 10))
                    self.damage.__delitem__(a[0])
                    self.score += 50
                    a[0].kill()
            else:
                self.damage[a[0]] = 1

        if self.PLAYING:
            if len(pygame.sprite.spritecollide(self.spaceshipgroup.sprite, self.asteroidgroup, True, pygame.sprite.collide_circle)) != 0:
                self.spaceshipgroup.add(S_Explosion(self.a_explode_pieces, self.spaceshipgroup.sprite.rect, 10))
                self.a_explosion.play()
                self.PLAYING = False
                self.CONTINUESHOT = False
                
        
                
                

        
