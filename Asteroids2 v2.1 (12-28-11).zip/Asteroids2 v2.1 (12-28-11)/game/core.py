"""This module defines all the events in this game"""
import pygame, sys
from pygame.locals import *
from asteroids import Asteroid
from spaceship import Spaceship
from highscore import Highscore

class Core:

    def __init__(self, event):
        if event.type == QUIT:
            pygame.quit()
            sys.exit()
            
        if self.MENU:
            self.menuhandle(event)
        elif self.GAME:
            self.gamehandle(event)
        elif self.HIGHSCORE:
            self.highscorehandle(event)

    def menuhandle(self, event):
        if event.type == KEYDOWN:
            if event.key == K_w and self.fontchoice != 0:
                self.fontchoice -= 1
            elif event.key == K_s and self.fontchoice != 2:
                self.fontchoice += 1
            elif event.key == K_SPACE:
                if self.fontchoice == 0:
                    self.MENU = False
                    self.GAME = True
                    if self.spaceshipgroup.sprite is None:
                        self.spaceshipgroup.add(Spaceship())
                        self.score = 0
                        self.asteroidgroup.empty()
                        self.CONTINUESHOT = True
                        self.PLAYING = True
                    pygame.time.set_timer(USEREVENT, 300)
                elif self.fontchoice == 1:
                    Highscore.update_high(self)
                    self.MENU = False
                    self.MENU_H = True
                    self.HIGHSCORE = True
                elif self.fontchoice == 2:
                    pygame.quit()
                    sys.exit()

    def highscorehandle(self, event):
        if event.type == KEYDOWN:
            if event.key == K_SPACE:
                self.HIGHSCORE = False
                self.MENU = True
                self.MENU_H = False

    def gamehandle(self, event):
        if event.type == MOUSEBUTTONDOWN:
            if event.button == 1:
                self.SHOOTING = True
            if event.button == 3:
                self.spaceshipgroup.sprite.MOVING = True

        if event.type == MOUSEBUTTONUP:
            if event.button == 1:
                self.SHOOTING = False
            if event.button == 3:
                self.spaceshipgroup.sprite.MOVING = False

        if event.type == KEYDOWN:
            if event.key == K_SPACE:
                self.spaceshipgroup.sprite.MOVING = True

        if event.type == KEYUP:
            if event.key == K_SPACE:
                self.spaceshipgroup.sprite.MOVING = False
                
        if event.type == USEREVENT:
            self.asteroidgroup.add(Asteroid(self.asteroid_pieces))


