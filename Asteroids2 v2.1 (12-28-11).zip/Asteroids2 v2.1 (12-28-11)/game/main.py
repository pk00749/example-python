"""This is the central module of the game"""
import pygame, os
from spritesheets import SpriteSheet
from sound import Sound
from menu import Menu
from core import Core
from game import Game
from highscore import Highscore

WIDTH, HEIGHT = 800, 500

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Asteroids 2")

background = pygame.image.load(os.path.join("graphics", "space.bmp")).convert()
background = pygame.transform.scale(background, (WIDTH, HEIGHT))

class PlayAsteroids(SpriteSheet, Menu, Game, Highscore, Sound, Core):

    def __init__(self):
        pygame.init()
        self.ON = True
        self.MENU = True
        self.MENU_H = False
        self.GAME = False
        self.HIGHSCORE = False
        self.BLIT = True

        pygame.mouse.set_visible(False)

        self.initializer()
        self.playgame()

    def initializer(self):
        SpriteSheet.__init__(self)
        Sound.__init__(self)
        Menu.__init__(self)
        Game.__init__(self)
        Highscore.__init__(self)

    def playgame(self):

        self.soundtrack.play(-1)

        while self.ON:
            if self.MENU:
                Menu.render(self, screen, background, self.spaceman_pieces)
                pygame.display.update()
            elif self.GAME:
                Game.render(self, screen, background, pygame.time.get_ticks())
                pygame.display.update()
            elif self.HIGHSCORE:
                Highscore.render(self, screen, background, self.spaceman_pieces)
                pygame.display.update()
            for event in pygame.event.get():
                Core.__init__(self, event)
            
                
    

