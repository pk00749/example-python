"""This shows the initial screen for Asteroids 2 v2.0"""
import pygame, os

WIDTH, HEIGHT = 800, 500
WHITE = (255, 255, 255)
GRAY = (170, 170, 170)

class Menu:

    def __init__(self, fps = 40):
        self.logo = pygame.image.load(os.path.join("graphics", "logo.png")).convert()
        self.logo = pygame.transform.scale(self.logo, (int(3.5*WIDTH/4), HEIGHT/4))
        self.logo.set_colorkey(self.logo.get_at((0, 0)))

        font = pygame.font.SysFont("Jokerman", 30)
        self.newgame_o = font.render("New Game", True, WHITE)
        self.newgame_f = font.render("New Game", True, GRAY)
        self.settings_o = font.render("Quit", True, WHITE)
        self.settings_f = font.render("Quit", True, GRAY)
        self.highscores_o = font.render("High Scores", True, WHITE)
        self.highscores_f = font.render("High Scores", True, GRAY)
        
        self.fontchoice = 0

        self.frame = 0
        self.frame_m = 0
        self.frame_m2 = 1
        self.delay = 1000/fps
        self.update_time = 0
        self.update_time_m = 0

    def render(self, screen, background, pieces):
        t = pygame.time.get_ticks()
        screen.blit(background, (0, 0))
        screen.blit(self.logo, (50, 50))
        screen.blit(self.asteroid_pieces[self.frame], (WIDTH/2 - self.asteroid_pieces[self.frame].get_width()/2,
                                                       HEIGHT/2 - self.asteroid_pieces[self.frame].get_height()/2))
        screen.blit(pieces[self.frame_m], (700, 50))
        screen.blit(pieces[self.frame_m2], (300, 50))
        if t - self.update_time > self.delay:
            self.frame += 1
            if self.frame_m == 3:
                self.frame_m = 0
            if self.frame == 142:
                self.frame = 0
            self.update_time = t

        if t - self.update_time_m > 1000:
            self.frame_m += 1
            self.frame_m2 += 1
            if self.frame_m == 3:
                self.frame_m = 0
            if self.frame_m2 == 3:
                self.frame_m2 = 0
            self.update_time_m = t 
            
        if self.fontchoice == 0:
            screen.blit(self.newgame_o, (WIDTH/2 - self.newgame_o.get_width()/2, 2*HEIGHT/3))
            screen.blit(self.highscores_f, (WIDTH/2 - self.highscores_f.get_width()/2, 2*HEIGHT/3 + 35))
            screen.blit(self.settings_f, (WIDTH/2 - self.settings_f.get_width()/2, 2*HEIGHT/3 + 70))

        elif self.fontchoice == 1:
            screen.blit(self.newgame_f, (WIDTH/2 - self.newgame_f.get_width()/2, 2*HEIGHT/3))
            screen.blit(self.highscores_o, (WIDTH/2 - self.highscores_f.get_width()/2, 2*HEIGHT/3 + 35))
            screen.blit(self.settings_f, (WIDTH/2 - self.settings_o.get_width()/2, 2*HEIGHT/3 + 70))
            
        elif self.fontchoice == 2:
            screen.blit(self.newgame_f, (WIDTH/2 - self.newgame_f.get_width()/2, 2*HEIGHT/3))
            screen.blit(self.highscores_f, (WIDTH/2 - self.highscores_o.get_width()/2, 2*HEIGHT/3 + 35))
            screen.blit(self.settings_o, (WIDTH/2 - self.settings_f.get_width()/2, 2*HEIGHT/3 + 70))
