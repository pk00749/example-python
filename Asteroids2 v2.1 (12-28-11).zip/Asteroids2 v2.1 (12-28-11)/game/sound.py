"""This game controls the sound effects and music of the game"""

import pygame, os, pygame.mixer

class Sound:

    def __init__(self):

        self.a_explosion = pygame.mixer.Sound(os.path.join("sounds", "asteroid_explosion.wav"))
        self.laser = pygame.mixer.Sound(os.path.join("sounds", "laser.wav"))
        self.soundtrack = pygame.mixer.Sound(os.path.join("sounds", "soundtrack.wav"))
