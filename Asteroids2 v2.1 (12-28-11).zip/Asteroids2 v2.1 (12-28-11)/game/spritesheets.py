"""This module makes sprites out of spritesheets"""
import pygame, os

WIDTH, HEIGHT = 800, 500

class SpriteSheet:

    def __init__(self):
        self.CAsteroid()
        self.CBullet()
        self.CExhaust()
        self.CA_Explosion()
        self.CSpaceman()    

    def CAsteroid(self):
        self.asteroidgroup = pygame.sprite.RenderUpdates()
        self.ast_sheet = pygame.image.load(os.path.join("graphics", "asteroid.png")).convert()
        self.ast_sheet.set_colorkey(self.ast_sheet.get_at((0, 0)))

        self.asteroid_pieces = []
        width, height = self.ast_sheet.get_width()/21, self.ast_sheet.get_height()/7
        
        for b in xrange(6):
            for a in xrange(21):
                a_sprite = self.ast_sheet.subsurface(a*width, b*height, width, height)
                self.asteroid_pieces.append(a_sprite)

        for a in xrange(17):
            a_sprite = self.ast_sheet.subsurface(a*width, 6*height, width, height)
            self.asteroid_pieces.append(a_sprite)

    def CBullet(self):
        self.bulletsheet = pygame.image.load(os.path.join("graphics", "bullet.png")).convert()
        self.bulletsheet.set_colorkey(self.bulletsheet.get_at((0, 0)))

        width, height = self.bulletsheet.get_width()/3, self.bulletsheet.get_height()/3
        self.bullet_pieces = []
        
        for a in xrange(3):
            bullet = self.bulletsheet.subsurface(a*width, 0, width, height)
            if a == 1:
                self.bullet_pieces.append(bullet)

    def CExhaust(self):
        self.ex_sheet = pygame.image.load(os.path.join("graphics", "exhaust.bmp")).convert()
        self.ex_sheet.set_colorkey(self.ex_sheet.get_at((0, 0))) 

        width, height = self.ex_sheet.get_width()/8, self.ex_sheet.get_height()/4
        self.exhaust_pieces = []

        for b in xrange(4):
            for a in xrange(8):
                ex_sprite = self.ex_sheet.subsurface(a*width, b*height, width, height)
                self.exhaust_pieces.append(ex_sprite)

    def CSpaceman(self):
        self.man_sheet = pygame.image.load(os.path.join("graphics", "spaceman.bmp")).convert()
        self.man_sheet.set_colorkey(self.man_sheet.get_at((0, 0)))

        width, height = self.man_sheet.get_width()/3, self.man_sheet.get_height()
        self.spaceman_pieces = []
        
        for a in xrange(3):
            man_sprite = self.man_sheet.subsurface(a*width, 0, width, height)
            self.spaceman_pieces.append(man_sprite)
            
    def CA_Explosion(self):
        self.a_explodesheet = pygame.image.load(os.path.join("graphics", "a_explode.bmp")).convert()
        self.a_explodesheet.set_colorkey(self.a_explodesheet.get_at((0, 0)))

        width, height = self.a_explodesheet.get_width()/4, self.a_explodesheet.get_height()/2
        self.a_explode_pieces = []

        for b in xrange(2):
            for a in xrange(4):
                a_exsprite = self.a_explodesheet.subsurface(a*width, b*height, width, height)
                self.a_explode_pieces.append(a_exsprite)
