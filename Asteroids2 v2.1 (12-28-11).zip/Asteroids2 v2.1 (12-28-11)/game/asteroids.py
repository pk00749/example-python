"""This module gives asteroids their unique properties"""
import pygame, random
from math import sqrt

WIDTH, HEIGHT = 800, 500

class Asteroid(pygame.sprite.Sprite):

    def __init__(self, pieces, fps = 40):
        pygame.sprite.Sprite.__init__(self)
        self.asteroid = pieces

        self.delay = 1000/fps
        self.update_time = 0
        self.frame = random.randint(0, 142)
        self.size = pieces[0].get_size()

        x = random.random()*WIDTH
        y = random.random()*HEIGHT
        dx = random.random()*WIDTH - x
        dy = random.random()*HEIGHT - y
        
        if x >= 3*WIDTH/4:
            self.x_a = x + WIDTH/4 + 50
        elif x < 3*WIDTH/4 and x >= WIDTH/2:
            self.x_a = x + WIDTH/2 + 50
        elif x < WIDTH/2 and x >= WIDTH/4:
            self.x_a = x - WIDTH/2 - 50
        elif x < WIDTH/4:
            self.x_a = x - WIDTH/4 - 50
        if y >= HEIGHT/2:
            self.y_a = y + HEIGHT/2 + 50
        elif y < HEIGHT/2:
            self.y_a = y - HEIGHT/2 - 50
        
        d = sqrt(dx*dx + dy*dy)
        v = random.randrange(3, 8)
        self.dx = dx*v/d
        self.dy = dy*v/d

        self.image = self.asteroid[self.frame]
        self.rect = pygame.Rect((self.x_a, self.y_a), (self.size[0], self.size[1]))
        self.radius = self.size[1]/2

    def update(self, time):
        if time - self.update_time > self.delay:
            self.frame += 1
            if self.frame == 143:
                self.frame = 0
            self.update_time = time
            self.image = self.asteroid[self.frame]
            self.rect = self.rect.move(self.dx, self.dy)

class A_Explosion(pygame.sprite.Sprite):

    def __init__(self, pieces, rect, fps = 40):
        pygame.sprite.Sprite.__init__(self)

        self.frame = 0
        self.delay = 1000/fps
        self.update_time = 0

        self.a_explode = pieces

        self.rect = rect
        self.image = self.a_explode[self.frame]

    def update(self, time):
        if time - self.update_time > self.delay:
            self.frame += 1
            if self.frame == 7:
                self.kill()
            self.image = self.a_explode[self.frame]
            self.update_time = time

            
        
        
