"""This module controls the spaceship's movements and actions including bullets and cursor"""
import pygame, os
from math import *

WIDTH, HEIGHT = 800, 500
                    
class Cursor:

    def __init__(self, fps = 40):
        self.cursor_im = pygame.image.load(os.path.join("graphics", "crosshair.bmp")).convert()
        self.cursor_im.set_colorkey(self.cursor_im.get_at((0, 0)))

        self.delay = 1000/fps
        self.update_time = 0
        self.rotation = 0

        self.cursor = self.cursor_im

    def update(self, time):
        if time - self.update_time > self.delay:
            self.cursor = pygame.transform.rotate(self.cursor_im, -self.rotation)
            self.rotation += .15

class Bullet(pygame.sprite.Sprite):

    def __init__(self, pieces, sprite, fps = 40):
        pygame.sprite.Sprite.__init__(self)

        self.M_POSITION = (pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])

        self.speed_b = 5
        dx = self.M_POSITION[0] - sprite.rect.centerx
        dy = self.M_POSITION[1] - sprite.rect.centery
        self.d = sqrt(dx*dx + dy*dy)
        self.dx_b = dx*self.speed_b/self.d
        self.dy_b = dy*self.speed_b/self.d

        self.image = pieces[0]

        theta = degrees(atan2(dx, -abs(dy)))
        self.image = pygame.transform.rotate(pieces[0], -theta)
        if self.M_POSITION[1] > sprite.rect.centery:
            self.image = pygame.transform.flip(self.image, False, True)

        self.rect = pygame.Rect((sprite.rect.center), (self.image.get_size()))
        self.delay = 1000/fps
        self.update_time = 0

    def update(self, time):
        if time - self.update_time > self.delay:
            self.rect = self.rect.move(self.dx_b, self.dy_b)

class Spaceship(pygame.sprite.Sprite):

    def __init__(self, fps = 40):
        pygame.sprite.Sprite.__init__(self)

        self.spaceship_im = pygame.image.load(os.path.join("graphics", "spaceship.bmp")).convert()
        self.spaceship_im.set_colorkey(self.spaceship_im.get_at((0, 0)))
        self.crosshair_im = pygame.image.load(os.path.join("graphics", "crosshair.bmp")).convert()
        self.crosshair_im.set_colorkey(self.crosshair_im.get_at((0, 0)))
        self.crosshair = self.crosshair_im

        self.delay = 1000/fps
        self.update_time = 0

        self.SHOOTING = False
        self.MOVING = False

        self.image = self.spaceship_im
        self.rect = pygame.Rect((WIDTH/2 - self.image.get_width()/2, HEIGHT/2 - self.image.get_height()/2),
                                (self.image.get_size()))
      
    def update(self, time):
        if time - self.update_time > self.delay:
            self.update_time = time
            
            self.M_POSITION = (pygame.mouse.get_pos()[0] - self.crosshair.get_width()/2, pygame.mouse.get_pos()[1] - self.crosshair.get_height()/2)
            
            dx = self.M_POSITION[0] + self.crosshair.get_width()/2 - self.rect.centerx
            dy = self.M_POSITION[1] + self.crosshair.get_height()/2 - self.rect.centery
            self.d = sqrt(dx*dx + dy*dy)
            self.dx_s = dx*5/self.d
            self.dy_s = dy*5/self.d
            
            theta = degrees(atan2(self.M_POSITION[0] + self.crosshair.get_width()/2 - self.rect.centerx,
                                  -abs(self.M_POSITION[1] + self.crosshair.get_height()/2 - self.rect.centery)))

            self.image = pygame.transform.rotate(self.spaceship_im, -theta)
            if self.M_POSITION[1] < self.rect[1]:
                self.image = pygame.transform.flip(self.image, False, True)

            if self.d > 20:
                if self.MOVING:
                    self.rect.centerx += self.dx_s
                    self.rect.centery += self.dy_s

class S_Explosion(pygame.sprite.Sprite):

    def __init__(self, pieces, rect, fps = 40):
        pygame.sprite.Sprite.__init__(self)

        self.frame = 0
        self.delay = 1000/fps
        self.update_time = 0

        self.s_explode = pieces

        self.rect = rect
        self.image = self.s_explode[self.frame]

    def update(self, time):
        if time - self.update_time > self.delay:
            self.frame += 1
            if self.frame >= 7:
                self.kill()
            else:
                self.image = self.s_explode[self.frame]
                self.update_time = time
