This is Asteroids 2 v2.1 by Joshua Potter

____________________________________________________________________

Credits:

Soundtrack - Secret Circuit; Space Rhythm 1 obtained from freemusicarchive.org
laser.wav - junggle's btn107.wav obtained from freesound.org
explosion.wav - smcameron's bombexplosion.wav obtained from freesound.org
spaceship image - Octopus41092's image from exhange3d.com
asteroid spritesheet - http://blog.makeyourflashgame.com/338/to-make-a-game-in-flash-part-v-asteroids.html
other images from http://www.lostgarden.com/2005/03/download-complete-set-of-sweet-8-bit.html

______________________________________________________________________

Updates from last version:

Improved graphics
Improved gameplay
Better (hopefully controls)
Sound
High Scores

______________________________________________________________________


Open Asteroids 2 to begin.
To play, use wasd to move up or down in menu and space to select.
In game use mousebutton 1 to shoot, mousebutton3 or space to move.
Survive as long as possible.

_______________________________________________________________________

Possible future updates:
enemies, improved aiming, story mode?



